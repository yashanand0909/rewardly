create
    definer = root@localhost procedure update_contest_status(IN cur_date date)
BEGIN
	DECLARE done INT DEFAULT FALSE;
    DECLARE contest_id_p INT;
    DECLARE cur CURSOR FOR SELECT a.contest_id FROM contest WHERE end_date < cur_date and isactive = TRUE;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	OPEN cur;
    forloop: LOOP
		FETCH cur INTO contest_id_p;
        IF done THEN
			LEAVE forloop;
		END IF;
        call update_rewards();
        UPDATE contest SET active = FALSE WHERE contest_id = contest_id_p;
	END LOOP;
CLOSE cur;
END;

