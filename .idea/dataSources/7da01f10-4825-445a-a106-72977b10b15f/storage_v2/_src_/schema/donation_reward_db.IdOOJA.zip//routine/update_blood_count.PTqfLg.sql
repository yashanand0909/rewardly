create
    definer = root@localhost procedure update_blood_count(IN donor_username varchar(100), IN date_of_donation date,
                                                          IN quantity int)
BEGIN
	DECLARE done INT DEFAULT FALSE;
	DECLARE blood_donated INT;
    DECLARE updated_donation INT;
	DECLARE contest_id_p INT;
	DECLARE cur CURSOR FOR SELECT a.contest_id, a.blood_donated a FROM contest_donation left join contest b on a.contest_id = b.contest_id where donor_username = donor_username and b.start_date <= date_of_donation and date_of_donation <= b.end_date;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur;
	forloop: LOOP
		FETCH cur INTO contest_id_P, blood_donated;
		IF done THEN
			LEAVE forloop;
		END IF;
		SET updated_donation = blood_donated + quantity;
		UPDATE contest_donation SET blood_donated = updated_donation WHERE contest_id = contest_id and donor_username = donor_username;
	END LOOP;
CLOSE cur;
END;

