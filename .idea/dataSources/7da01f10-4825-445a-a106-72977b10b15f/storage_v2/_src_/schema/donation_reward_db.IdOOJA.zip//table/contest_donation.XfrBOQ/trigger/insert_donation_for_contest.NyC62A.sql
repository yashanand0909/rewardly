create definer = root@localhost trigger insert_donation_for_contest
    after insert
    on contest_donation
    for each row
BEGIN
    DECLARE donation_count INT;
    DECLARE start_date DATE;
    DECLARE end_date DATE;
    SET start_date = (SELECT start_time FROM contest where contest_id = NEW.contest_id);
    SET end_date = (SELECT end_time FROM contest where contest_id = NEW.contest_id);
    SET donation_count = (SELECT SUM(quantity) FROM donation WHERE date_of_donation >= start_date and date_of_donation <= end_date);
    IF donation_count != 0 THEN
        UPDATE contest_donation SET blood_donated = donation_count WHERE contest_id = NEW.contest_id and  donor_username = NEW.donor_username;
    END IF;
END;

